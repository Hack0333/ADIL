<?php
$conn=mysqli_connect("localhost","root","","blood") or die("Connection error");
?>
